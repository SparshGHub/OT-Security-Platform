(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_b805903d.css",
  "static/chunks/node_modules_78a5f69f._.js",
  "static/chunks/src_2abb58b1._.js"
],
    source: "dynamic"
});
