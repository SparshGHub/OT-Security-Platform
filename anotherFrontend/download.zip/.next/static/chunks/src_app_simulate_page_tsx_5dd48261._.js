(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1c8baff8._.js",
  "static/chunks/src_10d6d5f6._.js"
],
    source: "dynamic"
});
