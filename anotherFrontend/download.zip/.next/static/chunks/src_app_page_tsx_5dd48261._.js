(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_94b1fd64._.js",
  "static/chunks/node_modules_recharts_es6_fb50099e._.js",
  "static/chunks/node_modules_ccd80104._.js",
  "static/chunks/src_fbb26a66._.js"
],
    source: "dynamic"
});
