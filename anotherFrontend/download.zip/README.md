# OT Shield - OT Security Dashboard Frontend

This is a Next.js frontend for an Operational Technology (OT) security MVP. The application provides a clean, modern, and professional interface for simulating OT events and monitoring system health and alerts.

## Features

- **Real-time Alert Monitoring:** View live security alerts as they happen.
- **Recent Alert History:** Browse a table of the most recent security events.
- **OT Simulation:** Trigger mock Modbus write events to simulate setpoint changes and potential attacks.
- **System Health Overview:** Monitor WebSocket connection status, alert statistics, and trends.

## Tech Stack

- **Framework:** Next.js (React 18) with TypeScript
- **Styling:** Tailwind CSS with ShadCN UI components
- **State Management:** React Context and Hooks
- **Real-time Communication:** Native WebSocket API
- **Charting:** Recharts

---

## Getting Started Locally

Follow these steps to download the code and run it on your local machine.

### 1. Download Your Code

First, you'll need to get the code from this workspace onto your local machine. Look for a "Download" or "Export" button in the Studio interface to download a zip file of your project.

### 2. Unzip and Navigate

Once downloaded, unzip the file and open a terminal or command prompt inside the project folder.

### 3. Configure Your Backend API

Before running the application, you need to tell it where your backend is running.

1.  Find the file named `.env.local` in the root of the project. If it doesn't exist, create it.
2.  Open it and add the following line, replacing the URL if your backend is running on a different port:

```
NEXT_PUBLIC_API_BASE=http://localhost:8080
```

### 4. Install Dependencies

In your terminal, run the following command to install all the necessary packages:

```bash
npm install
```

### 5. Run the Development Server

Now you can start the application:

```bash
npm run dev
```

The application will be available at `http://localhost:9002`. It should now be connected to your local backend.

---
## Docker

You can also run the application using Docker.

1.  Build the Docker image:
    ```bash
    docker build -t ot-shield-frontend .
    ```

2.  Run the container. You must pass the backend API URL as an environment variable. **Make sure to use `host.docker.internal` instead of `localhost`** if your backend is also running locally.

    ```bash
    docker run -p 9002:9002 \
      -e NEXT_PUBLIC_API_BASE=http://host.docker.internal:8080 \
      ot-shield-frontend
    ```
The application will be available at `http://localhost:9002`.
