'use server';

// This file is intentionally left blank after removing AI-related actions.
