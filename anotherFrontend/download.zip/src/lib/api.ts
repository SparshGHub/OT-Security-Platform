import type { Alert, DrumSimulation, LoadSimulation } from "@/lib/types";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:8080';

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const errorText = await response.text().catch(() => 'Could not read error response.');
    throw new Error(`API Error ${response.status}: ${errorText || response.statusText}`);
  }
  const text = await response.text();
  return text ? JSON.parse(text) : ({} as T);
}

export async function getAlerts(limit = 20): Promise<Alert[]> {
  const response = await fetch(`${API_BASE}/alerts?limit=${limit}`, { cache: 'no-store' });
  return handleResponse<Alert[]>(response);
}

export async function simulateDrum(data: Omit<DrumSimulation, 'site_id'>): Promise<any> {
  const body: DrumSimulation = { ...data, site_id: "Thermal - Demo" };
  const response = await fetch(`${API_BASE}/simulate/modbus-write-drum`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return handleResponse(response);
}

export async function simulateLoad(data: Omit<LoadSimulation, 'site_id'>): Promise<any> {
  const body: LoadSimulation = { ...data, site_id: "Thermal - Demo" };
  const response = await fetch(`${API_BASE}/simulate/modbus-write-load`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return handleResponse(response);
}
